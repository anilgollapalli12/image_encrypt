import React, { Component } from 'react';
import Home from './Home';
import "antd/dist/antd.css";

class App extends Component {
  render() {
    return (
      <Home/>
    );
  }
}

export default App;
